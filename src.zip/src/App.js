import "./App.css";
import { Route, Routes } from "react-router-dom";
import AccountDetails from "./components/account/accountDetails";
import Header from "./components/Header";
import Footer from "./components/Footer";
import SellDetails from "./components/sell/SellDetails";
import ProductFeatures from "./components/account/productFeatures";
import ProductDescription from "./components/account/productDescription";

function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<AccountDetails />} />

        <Route path="/sell" element={<SellDetails />} />
        <Route path="/features/:id" element={<ProductFeatures />} />
        <Route path="/description/:id" element={<ProductDescription />} />
      </Routes>
      <Footer />
    </>
  );
}

export default App;
