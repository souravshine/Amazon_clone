import React, { useState } from "react";
import { useEffect } from "react";
import axios from "axios";
import "./productDetails.css";
import { Link } from "react-router-dom";

const ProductDetails = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      console.log("testing 1");
      const fetchedProducts = await axios.get("https://dummyjson.com/products");
      if (fetchedProducts) {
        setProducts(fetchedProducts?.data?.products);
      }
    } catch (error) {
      console.log(error);
    }
  };
  console.log(products);

  return (
    // <>
    //   <div className="container">
    //     <ul>
    //       {products.length &&
    //         products.map((product) => (
    //           <li className="product" key={product.id}>
    //             <div>
    //               <img src={product.images[0]} alt={product.title} />
    //             </div>
    //             <div>{product.title}</div>
    //             <div>{product.price}</div>
    //             <p>{product.description}</p>
    //           </li>
    //         ))}
    //     </ul>
    //   </div>
    // </>
    <>
      <div className="container">
        {products.length &&
          products.map((product) => (
            <div className="card" key={product.id}>
              <div>
                <Link to={`/features/${product.id}`}>
                  <img src={product.images[0]} alt={product.title} />
                </Link>
              </div>
              <div className="details">
                <div className="row title">{product.title}</div>
                <div className="row price">Rs.{product.price}</div>
                <hr></hr>
                {/* <p className="description">{product.description}</p> */}
              </div>
              <Link to={`/features/${product.id}`}>
                <button className="btn">View Details</button>
              </Link>
            </div>
          ))}
      </div>
    </>
  );
};
export default ProductDetails;
