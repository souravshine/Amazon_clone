import axios from "axios";
import React, { useCallback, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import "./productFeatures.css";
import productsData from "../../assets/cartDetails.json";

const ProductFeatures = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const params = useParams();

  const addToCart = () => {
    const cartItems = window.localStorage.getItem("cart");
    if (cartItems) {
      const newCartItems = JSON.parse(cartItems);

      newCartItems.push(id);

      window.localStorage.setItem("cart", JSON.stringify(newCartItems));
    } else {
      const newCartItems = [];

      newCartItems.push(id);

      window.localStorage.setItem("cart", JSON.stringify(newCartItems));
    }
  };

  useEffect(() => {
    console.log("params", params);
    console.log("xyz", productsData);
    const productResult = productsData.cartDetails.filter((product) => {
      return product.id == params.id;
    });
    console.log("selected product", productResult);
    setProduct(productResult[0]);
  }, [params]);

  // const fetchProducts = useCallback(async () => {
  //   try {
  //     const fetchedProducts = await axios.get(
  //       `https://dummyjson.com/products/${id}`
  //     );
  //     if (fetchedProducts.data) {
  //       setProduct(fetchedProducts.data);
  //     }
  //   } catch (error) {
  //     console.log(error);
  //   }
  // }, [id]);

  //useEffect(() => {
  //   fetch Products();
  // }, [fetchProducts]);

  return (
    product && (
      <>
        <div className="parent">
          <div>
            <img
              className="imags"
              src={product?.images?.[0]}
              alt={product?.title}
            />
          </div>
          <div className="detailss">
            <div>
              <h1>Rs.{product?.price}</h1>
              <p>{product?.description}</p>
            </div>
            <span>
              <button className="btn buy">Buy Now</button>{" "}
              <button className="btn add" onClick={addToCart}>
                Add to Cart
              </button>
            </span>
          </div>
        </div>
      </>
    )
  );
};

export default ProductFeatures;
