import React, { useEffect, useState } from "react";
import productsData from "../../assets/cartDetails.json";

const ProductDetails = ({ productId }) => {
  const [product, setProduct] = useState(null);

  useEffect(() => {
    console.log("xyz", productsData);
  }, []);

  // Simulate fetching product details
  const fetchProductDetails = () => {
    const productDetails = productsData.cartDetails.find(
      (item) => item.id === productId
    );
    setProduct(productDetails);
  };

  // Simulate "Buy Now" action
  const handleBuyNow = () => {
    // Add logic for handling the "Buy Now" action
    console.log("Buying now:", product);
  };

  return (
    <div>
      <h2>Product Details</h2>
      <button onClick={fetchProductDetails}>Fetch Details</button>

      {product && (
        <div>
          <h3>{product.name}</h3>
          <p>{product.description}</p>
          <p>Price: ${product.price}</p>
          <p>hjsjvjhhdjhd</p>
          <button onClick={handleBuyNow}>Buy Now</button>
        </div>
      )}
    </div>
  );
};

export default ProductDetails;
