import React, { useState } from "react";

const UserDetail = () => {
  const [user, setUser] = useState({
    name: "",
    email: "sourav1@gmail.com",
    phone: "+91 2345223322",
  });

  const [inputValues, setInputValues] = useState({
    name: "",
    email: "",
    phone: "",
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setInputValues({
      ...inputValues,
      [name]: value,
    });
  };

  const changeUserDetails = () => {
    setUser({
      name: inputValues.name || user.name,
      email: inputValues.email || user.email,
      phone: inputValues.phone || user.phone,
    });
  };

  return (
    <div>
      <h2>User Details</h2>
      <input
        type="text"
        placeholder="Name"
        name="name"
        value={inputValues.name}
        onChange={handleChange}
      />
      <input
        type="text"
        placeholder="Email"
        name="email"
        value={inputValues.email}
        onChange={handleChange}
      />
      <input
        type="text"
        placeholder="Phone"
        name="phone"
        value={inputValues.phone}
        onChange={handleChange}
      />
      <button onClick={changeUserDetails}>Change User</button>
      <p>Name: {user?.name}</p>
      <p>Email: {user?.email}</p>
      <p>Phone: {user?.phone}</p>
    </div>
  );
};

export default UserDetail;
