import React from "react";
import ProductDetails from "./productDetails";

const AccountDetails = () => {
  return <div>{<ProductDetails />}</div>;
};

export default AccountDetails;
