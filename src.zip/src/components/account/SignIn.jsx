import React from "react";

const SignIn = () => {
  return (
    <div className="container">
      <h2>Sign In</h2>
      <form action="/submit" method="post">
        <label htmlFor="username">Username:</label>
        <br />
        <input type="text" id="username" name="username" required />
        <br />
        <label htmlFor="password">Password:</label>
        <br />
        <input type="password" id="password" name="password" required />
        <br />
        <br />
        <input type="submit" value="Sign In" />
      </form>
    </div>
  );
};

export default SignIn;
