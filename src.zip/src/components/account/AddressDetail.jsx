import React from "react";

const AddressDetail = () => {
  const sampleAddress = {
    street: "123 Main St",
    city: "Exampleville",
    state: "CA",
    zipCode: "12345",
  };

  return <div>Address details</div>;
};

export default AddressDetail;
