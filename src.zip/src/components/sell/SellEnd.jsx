import React from "react";

const SellEnd = () => {
  const handleCompleteSale = () => {
    alert("Sale completed!");
    // You can add additional logic here for completing the sale process
  };

  return (
    <div>
      <h2>Complete Sale</h2>
      <p>Thank you for using our platform to sell your items.</p>
      <button onClick={handleCompleteSale}>Complete Sale</button>
    </div>
  );
};

export default SellEnd;
