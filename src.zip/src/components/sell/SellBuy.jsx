import React from "react";
import { useState } from "react";

const SellBuy = () => {
  const [buyQuantity, setBuyQuantity] = useState(0);
  const [sellQuantity, setSellQuantity] = useState(0);

  // Define functions to handle changes in input fields
  const handleBuyChange = (e) => {
    setBuyQuantity(e.target.value);
  };

  const handleSellChange = (e) => {
    setSellQuantity(e.target.value);
  };

  return (
    <div>
      <h2>Sell and Buy</h2>
      <div>
        <label>
          Buy Quantity:
          <input type="number" value={buyQuantity} onChange={handleBuyChange} />
        </label>
        <button onClick={() => alert(`You want to buy ${buyQuantity} items!`)}>
          Buy
        </button>
      </div>
      <div>
        <label>
          Sell Quantity:
          <input
            type="number"
            value={sellQuantity}
            onChange={handleSellChange}
          />
        </label>
        <button
          onClick={() => alert(`You want to sell ${sellQuantity} items!`)}
        >
          Sell
        </button>
      </div>
    </div>
  );
};

export default SellBuy;
