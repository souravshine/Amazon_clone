import React from "react";
import { useState } from "react";

const SellStart = () => {
  const [itemName, setItemName] = useState("");
  const [itemPrice, setItemPrice] = useState("");

  const handleItemNameChange = (e) => {
    setItemName(e.target.value);
  };

  const handleItemPriceChange = (e) => {
    setItemPrice(e.target.value);
  };

  const handleStartSale = () => {
    alert(`You want to sell ${itemName} for $${itemPrice}.`);
    // You can add additional logic here for starting the sale process
  };

  return (
    <div>
      <h2>Start a New Sale</h2>
      <div>
        <label htmlFor="Item Name">Item Name:</label>
        <br />
        <input type="text" value={itemName} onChange={handleItemNameChange} />
        <br />
      </div>
      <div>
        <label>
          Item Price:
          <input
            type="number"
            value={itemPrice}
            onChange={handleItemPriceChange}
          />
        </label>
      </div>
      <button onClick={handleStartSale}>Start Sale</button>
    </div>
  );
};

export default SellStart;
