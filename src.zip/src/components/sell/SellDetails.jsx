import React from "react";
import SellBuy from "./SellBuy";
import SellEnd from "./SellEnd";
import SellStart from "./SellStart";

const SellDetails = () => {
  return (
    <div>
      <SellBuy />
      <SellEnd />
      <SellStart />
    </div>
  );
};

export default SellDetails;
