import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <>
      <ul className="myNavbar">
        <li>
          <Link to="/AddressDetail">Privacy notice</Link>
        </li>
        <li>
          <Link to="/signin">instead based ads</Link>
        </li>
        <li>
          <Link to="/sellBuy">sell details</Link>
        </li>
      </ul>
    </>
  );
};

export default Footer;
