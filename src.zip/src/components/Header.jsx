import React from "react";
import { Link } from "react-router-dom";
import "./Header.css";

const Header = () => {
  return (
    <>
      <div className="Navbar">
        <ul className="myNavbar">
          <Link className="li" to="/SellStart">
            Todays deal
          </Link>

          <Link className="li" to="/">
            New learning
          </Link>

          <Link className="li" to="/sell">
            Sell
          </Link>
        </ul>
      </div>
    </>
  );
};

export default Header;
